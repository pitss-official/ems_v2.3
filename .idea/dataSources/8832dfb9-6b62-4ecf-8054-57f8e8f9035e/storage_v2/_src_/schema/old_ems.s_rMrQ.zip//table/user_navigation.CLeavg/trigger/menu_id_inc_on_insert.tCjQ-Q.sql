create definer = root@localhost trigger menu_id_inc_on_insert
    before INSERT
    on user_navigation
    for each row
    SET NEW.menu_id = (SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'emsexpress' AND TABLE_NAME = 'user_navigation')+19;

